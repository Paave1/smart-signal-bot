# Smart Signal Bot

Webhook-приемник сигналов TradingView для Telegram